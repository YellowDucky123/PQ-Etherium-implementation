"""
Examples for XMSS implementation
"""